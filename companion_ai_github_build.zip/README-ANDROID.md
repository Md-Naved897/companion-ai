# Companion AI Android-ready project

## What this is
A Capacitor wrapper around the existing Companion AI web demo.

## Build APK
Install Node.js and Android Studio first.

In this folder:

1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`

Android Studio will open. Then use:
**Build > Build Bundle(s) / APK(s) > Build APK(s)**

## Important
The included demo works without an AI API key, but it is a demo.
The real AI backend (`server.js`) must be hosted separately and connected to the app for real AI responses.

For production, use HTTPS and keep API keys only on the server.
