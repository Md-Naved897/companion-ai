const $=s=>document.querySelector(s);
let character={name:"Aarav",personality:"calm friendly supportive"},trust=1;
let history=JSON.parse(localStorage.getItem("companionHistory")||"[]");
function stage(){return trust<=20?"Stranger":trust<=40?"Acquaintance":trust<=60?"Friend":trust<=80?"Close Friend":"Strong Bond"}
function renderTrust(){$("#trust").value=trust;$("#score").textContent=trust+"/100";$("#stage").textContent=stage()}
function bubble(t,c){let d=document.createElement("div");d.className="bubble "+c;d.textContent=t;$("#chat").appendChild(d);$("#chat").scrollTop=$("#chat").scrollHeight}
document.querySelectorAll(".char").forEach(b=>b.onclick=()=>{document.querySelectorAll(".char").forEach(x=>x.classList.remove("active"));b.classList.add("active");character={name:b.dataset.name,personality:b.dataset.personality};$("#callName").textContent=character.name;bubble("Ab main "+character.name+" hoon 😊",'ai')});
$("#image").onchange=e=>{let f=e.target.files[0];if(!f)return;let url=URL.createObjectURL(f);$("#preview").innerHTML='<img src="'+url+'" alt="Selected image">';bubble("📷 Image select ho gayi. AI provider connect hone par is image ko analyze kar sakte ho.","ai")};
$("#mic").onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){bubble("Is browser mein voice input supported nahi hai.","ai");return}let r=new SR();r.lang="hi-IN";r.onresult=e=>$("#message").value=e.results[0][0].transcript;r.start()};
$("#form").onsubmit=async e=>{e.preventDefault();let m=$("#message").value.trim();if(!m)return;bubble(m,"user");$("#message").value="";history.push({role:"user",content:m});if(trust<100)trust=Math.min(100,trust+1);renderTrust();try{let r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({character,message:m,history,trust})});let d=await r.json();bubble(d.reply||"AI reply nahi mila.","ai");history.push({role:"assistant",content:d.reply||""});localStorage.setItem("companionHistory",JSON.stringify(history.slice(-30)))}catch{bubble("Backend connect nahi hua. Server/API setup check karo.","ai")}};
$("#callBtn").onclick=()=>$("#modal").classList.remove("hidden");$("#end").onclick=()=>$("#modal").classList.add("hidden");$("#mute").onclick=e=>e.target.textContent=e.target.textContent==="🎙️"?"🔇":"🎙️";
renderTrust();
